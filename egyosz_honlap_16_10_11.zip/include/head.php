<?php
echo("
<html>
	<head>
		<meta charset='UTF-8' />
		<title>" .$maintitle. "</title>

		<link rel='stylesheet' href='./bootstrap/css/bootstrap.css'>
		<link rel='stylesheet' href='./bootstrap/material/css/material-fullpalette.css'>
		<link rel='stylesheet' href='./bootstrap/material/css/ripples.css'>
		<link rel='stylesheet' href='./bootstrap/material/css/roboto.css'>
		<link rel='stylesheet' href='./style/custom_bootstrap.css'>

		<script type='text/javascript' src='./js/jquery-2.1.4.min.js'></script>
		<script type='text/javascript' src='./js/init.js'></script>
		<script type='text/javascript' src='./bootstrap/js/bootstrap.js'></script>
		<script type='text/javascript' src='./bootstrap/material/js/material.js'></script>
		<script type='text/javascript' src='./bootstrap/material/js/ripples.js'></script>

		<!--
		<link rel='stylesheet' type='text/css' href='style/defaultstyle.css' />
		<link rel='stylesheet' type='text/css' href='style/" .$theme. "/style.css' />
		-->
		<link rel='shortcut icon' href='style/favicon.ico' />
		<script src='theme/" .$theme. "/themeScript.js '></script>
	</head>
	<body>");
?>
