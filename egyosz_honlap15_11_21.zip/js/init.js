document.addEventListener('DOMContentLoaded', function(){
    $.material.init();
  }, false)
