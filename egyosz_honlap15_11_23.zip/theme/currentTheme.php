<?php

$maintitle = "Illyés-napok 2015";
$date = mktime(0,0,0,12,16,2015);		// the date you want to display when the event will take place
$deadline = "2015. 12. 05.";	// the date you want to display as the deadline of the registration

$theme = "illyesnapok"; //you can choose from: "illyesnapok"; "egyosznap"; "tanarertekeles"
$welcomeText = "Köszöntünk az Egyosz oldalán!";
$description = "Idén is, mint azt már megszokhattátok, az interneten kell regisztrálnotok az Illyés-napi produkcióitokat.";

/*$bottomLineText = "
<p><b>". $maintitle ." - Jelentkezési rendszer </b> <br/>
Ötletgazda: Solymosi Máté, A rendszer tervezője és üzemeltetője: Süvegh Dávid, Látványterv: Szakács Norbert <br/>
Az üzemeltetők ügyelnek a rendszerben tárol adatok biztonságára és nem adják ki azokat harmadik félnek.</p>
";*/

$bottomLineText = "Készítő és üzemeltető: Süvegh Dávid - Design: Gergály Benedek <br>
	Az üzemeltetők ügyelnek a rendszerben tárolt adatok biztonságára és nem adják ki azokat harmadik félnek.";

//THEME SPECIFIC VARIABLES

	//egyosznap
		$timelineNumber = 2; //gives that how many timeline should the program handle

	//illyesnapok


	//tanarertekeles


?>
