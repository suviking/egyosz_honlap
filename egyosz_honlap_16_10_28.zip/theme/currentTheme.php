<?php

$maintitle = "Illyés Napok - 2016";
$date = mktime(0,0,0,3,18,2016);		// the date you want to display when the event will take place
$deadLine = "2016,11,05,23,59,59";	// the date you want to display as the deadline of the registration
$deadLineDate = new DateTime('2016-12-05 23:59:59', new DateTimeZone('Europe/Rome'));
$deadLineTS = date_timestamp_get($deadLineDate); //the UNIX timestamp of the deadLineDate

$theme = "illyesnapok"; //you can choose from: "illyesnapok"; "egyosznap"; "tanarertekeles"
$welcomeText = "Köszöntünk az Egyosz oldalán!";
$description = "Idén is, mint azt már megszokhattátok, az interneten kell jelentkeznetek az Illyés Napok-ra a produkcióitokkal.";

/*$bottomLineText = "
<p><b>". $maintitle ." - Jelentkezési rendszer </b> <br/>
Ötletgazda: Solymosi Máté, A rendszer tervezője és üzemeltetője: Süvegh Dávid, Látványterv: Szakács Norbert <br/>
Az üzemeltetők ügyelnek a rendszerben tárol adatok biztonságára és nem adják ki azokat harmadik félnek.</p>
";*/

$bottomLineText = "Készítő és üzemeltető: Süvegh Dávid - Design: Gergály Benedek <br>
	Az üzemeltetők ügyelnek a rendszerben tárolt adatok biztonságára és nem adják ki azokat harmadik félnek.";

//THEME SPECIFIC VARIABLES

	//egyosznap
		$timelineNumber = 1; //gives that how many timeline should the program handle

	//illyesnapok


	//tanarertekeles


?>
